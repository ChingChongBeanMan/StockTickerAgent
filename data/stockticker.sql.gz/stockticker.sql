--
-- 데이터베이스: `stockticker`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 테이블 구조 `heldstock`
--

CREATE TABLE `heldstock` (
  `Player` varchar(20) NOT NULL,
  `Amount` int(11) NOT NULL,
  `RetCode` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- 테이블 구조 `movements`
--

CREATE TABLE `movements` (
  `Datetime` varchar(19) DEFAULT NULL,
  `Code` varchar(4) DEFAULT NULL,
  `Action` varchar(4) DEFAULT NULL,
  `Amount` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `movements`
--

INSERT INTO `movements` (`Datetime`, `Code`, `Action`, `Amount`) VALUES
('Sun, 17 Apr 2016 13', 'MSFT', 'up', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'IND', 'div', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'div', 5),
('Sun, 17 Apr 2016 13', 'MSFT', 'div', 10),
('Sun, 17 Apr 2016 13', 'IND', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'div', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'IND', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 10),
('Sun, 17 Apr 2016 13', 'MSFT', 'down', 20),
('Sun, 17 Apr 2016 13', 'IBM', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 5),
('Sun, 17 Apr 2016 13', 'IBM', 'up', 20),
('Sun, 17 Apr 2016 13', 'IND', 'div', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'HD', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'div', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 20),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'HD', 'up', 5),
('Sun, 17 Apr 2016 13', 'IND', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'IND', 'down', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'IND', 'div', 10),
('Sun, 17 Apr 2016 13', 'MSFT', 'div', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 10),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'div', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'div', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 10),
('Sun, 17 Apr 2016 13', 'MSFT', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 10),
('Sun, 17 Apr 2016 13', 'HD', 'div', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IBM', 'down', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 10),
('Sun, 17 Apr 2016 13', 'MSFT', 'div', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20),
('Sun, 17 Apr 2016 13', 'HD', 'up', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 20),
('Sun, 17 Apr 2016 13', 'IBM', 'up', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'div', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'div', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'div', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'IND', 'down', 20),
('Sun, 17 Apr 2016 13', 'IBM', 'div', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IND', 'div', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'IND', 'down', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'IND', 'down', 10),
('Sun, 17 Apr 2016 13', 'MSFT', 'down', 20),
('Sun, 17 Apr 2016 13', 'HD', 'up', 5),
('Sun, 17 Apr 2016 13', 'MSFT', 'up', 20),
('Sun, 17 Apr 2016 13', 'IND', 'div', 20),
('Sun, 17 Apr 2016 13', 'IND', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'IND', 'div', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'BP', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'IND', 'div', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 5),
('Sun, 17 Apr 2016 13', 'GRAN', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 10),
('Sun, 17 Apr 2016 13', 'IND', 'div', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'div', 5),
('Sun, 17 Apr 2016 13', 'IND', 'up', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 5),
('Sun, 17 Apr 2016 13', 'MSFT', 'up', 20),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'HD', 'up', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 20),
('Sun, 17 Apr 2016 13', 'MSFT', 'up', 10),
('Sun, 17 Apr 2016 13', 'BP', 'up', 10),
('Sun, 17 Apr 2016 13', 'GRAN', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 10),
('Sun, 17 Apr 2016 13', 'IND', 'down', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'HD', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 20),
('Sun, 17 Apr 2016 13', 'IND', 'down', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'div', 10),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 5),
('Sun, 17 Apr 2016 13', 'IBM', 'up', 10),
('Sun, 17 Apr 2016 13', 'IND', 'div', 20),
('Sun, 17 Apr 2016 13', 'HD', 'up', 5),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 5),
('Sun, 17 Apr 2016 13', 'IND', 'down', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'MSFT', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'down', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'up', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'div', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'up', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 5),
('Sun, 17 Apr 2016 13', 'IND', 'div', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'MSFT', 'down', 10),
('Sun, 17 Apr 2016 13', 'HD', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 20),
('Sun, 17 Apr 2016 13', 'IND', 'div', 20),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 10),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'up', 5),
('Sun, 17 Apr 2016 13', 'BP', 'up', 5),
('Sun, 17 Apr 2016 13', 'DSC', 'down', 5),
('Sun, 17 Apr 2016 13', 'BP', 'down', 20),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20),
('Sun, 17 Apr 2016 13', 'BP', 'div', 10),
('Sun, 17 Apr 2016 13', 'IND', 'down', 20),
('Sun, 17 Apr 2016 13', 'GRAN', 'down', 20),
('Sun, 17 Apr 2016 13', 'IXP', 'div', 5),
('Sun, 17 Apr 2016 13', 'COFF', 'down', 10),
('Sun, 17 Apr 2016 13', 'BP', 'up', 20);

-- --------------------------------------------------------

--
-- 테이블 구조 `players`
--

CREATE TABLE `players` (
  `Player` varchar(6) DEFAULT NULL,
  `Cash` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `players`
--

INSERT INTO `players` (`Player`, `Cash`) VALUES
('Mickey', 1000),
('Donald', 3000),
('George', 2000),
('Henry', 2500),
('test', 1000);

-- --------------------------------------------------------

--
-- 테이블 구조 `stocks`
--

CREATE TABLE `stocks` (
  `Code` varchar(4) DEFAULT NULL,
  `Name` varchar(10) DEFAULT NULL,
  `Category` varchar(1) DEFAULT NULL,
  `Value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `stocks`
--

INSERT INTO `stocks` (`Code`, `Name`, `Category`, `Value`) VALUES
('BP', 'Believable', 'C', 35),
('COFF', 'Coffee', 'C', 95),
('DSC', 'Deathstar ', 'C', 125),
('GRAN', 'Grain', 'B', 90),
('HD', 'Harley Dav', 'A', 135),
('IBM', 'IBM', 'A', 145),
('IND', 'Industrial', 'B', 110),
('IXP', 'Inter-plan', 'C', 95),
('MSFT', 'Microsoft', 'A', 135);

-- --------------------------------------------------------

--
-- 테이블 구조 `transactions`
--

CREATE TABLE `transactions` (
  `DateTime` varchar(19) DEFAULT NULL,
  `Player` varchar(6) DEFAULT NULL,
  `Stock` varchar(4) DEFAULT NULL,
  `Trans` varchar(4) DEFAULT NULL,
  `Quantity` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `transactions`
--

INSERT INTO `transactions` (`DateTime`, `Player`, `Stock`, `Trans`, `Quantity`) VALUES
('2016.02.01-09:01:00', 'Donald', 'BOND', 'buy', 100),
('2016.02.01-09:01:05', 'Donald', 'TECH', 'sell', 1000),
('2016.02.01-09:01:10', 'Henry', 'TECH', 'sell', 1000),
('2016.02.01-09:01:15', 'Donald', 'IND', 'sell', 1000),
('2016.02.01-09:01:20', 'George', 'GOLD', 'sell', 100),
('2016.02.01-09:01:25', 'George', 'OIL', 'buy', 500),
('2016.02.01-09:01:30', 'Henry', 'GOLD', 'sell', 100),
('2016.02.01-09:01:35', 'Henry', 'GOLD', 'buy', 1000),
('2016.02.01-09:01:40', 'Donald', 'TECH', 'buy', 100),
('2016.02.01-09:01:45', 'Donald', 'OIL', 'sell', 100),
('2016.02.01-09:01:50', 'Donald', 'TECH', 'sell', 100),
('2016.02.01-09:01:55', 'George', 'OIL', 'buy', 100),
('2016.02.01-09:01:60', 'George', 'IND', 'buy', 100);

-- --------------------------------------------------------

--
-- 테이블 구조 `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(64) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `users`
--

INSERT INTO `users` (`username`, `password`, `role`) VALUES
('test', '$2y$10$qbPCFa2sJT2e7JB/JzFWUu/FzAGNIqLfzp7Uqv6Pj8v1NHlg5chBO', 'player');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- 테이블의 인덱스 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
